package practica;

import practica.realwork.ClassWhichRepo;

public class Main {

    public static void main(String[] args){
        ClassWhichRepo.round1();
        ClassWhichRepo.round2();
        ClassWhichRepo.round3();
    }
}
