package practica;

public class ConsoleColors {
    private static final String Green = "\033[0;32m";
}
